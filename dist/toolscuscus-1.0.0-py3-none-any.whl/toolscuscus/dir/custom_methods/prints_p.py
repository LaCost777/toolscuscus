""" This is the file to keep custom methods for prints. """
