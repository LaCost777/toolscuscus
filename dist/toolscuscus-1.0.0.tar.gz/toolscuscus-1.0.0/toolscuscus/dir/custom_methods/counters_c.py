"""This is file to keep custom counters and weird counters to learn 
how to use them in different project as a custom libraries. """


class BasicCode:
    def __int__(self, some_variable):
        self.variable = some_variable
        return self.variable
